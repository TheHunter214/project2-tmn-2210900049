﻿Public Class DonHang
    Public Property MaDonHang As Integer

    Public Property MaKhachHang As Integer

    Public Property NgayDatHang As DateTime

    Public Property TongTien As Decimal

    Public Property TrangThai As String

End Class
