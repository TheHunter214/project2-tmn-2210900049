﻿Public Class QuanTriVien
    Public Property MaQuanTriVien As Integer
    Public Property TenQuanTriVien As String
    Public Property Email As String
    Public Property MauKhau As String
    Public Property VaiTro As String
End Class
