﻿Public Class KhachHang
    Public Property MaKhachHang As Integer
    Public Property TenKhachHang As String
    Public Property Email As String
    Public Property MatKhau As String
    Public Property DiaChi As String
    Public Property SoDienThoai As String
    Public Property NgayDangKy As DateTime
End Class
