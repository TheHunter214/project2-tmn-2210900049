﻿
Public Class SanPham
    Public Property MaSanPham As Integer

    Public Property TenSanPham As String

    Public Property LoaiSanPham As String

    Public Property Gia As Decimal

    Public Property MoTa As String

    Public Property SoLuongTon As Integer
End Class
