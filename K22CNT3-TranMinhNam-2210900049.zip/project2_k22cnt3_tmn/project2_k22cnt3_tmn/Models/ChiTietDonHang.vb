﻿Public Class ChiTietDonHang
    Public Property MaChiTiet As Integer

    Public Property MaDonHang As Integer

    Public Property MaSanPham As Integer

    Public Property SoLuong As Integer

    Public Property Gia As Decimal
End Class
